package f;
import org.opencv.core.Core;
import org.opencv.core.Mat;
import org.opencv.core.MatOfPoint2f;
import org.opencv.core.Point;
import org.opencv.highgui.HighGui;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

class GeometricTransforms {
	 public void run(String[] args) {
	 String filename = args.length > 0 ? args[0] : "C:\\cat.jpg";
	 Mat src = Imgcodecs.imread(filename);
	 if (src.empty()) {
	 System.err.println("Cannot read image: " + filename);
	 System.exit(0);
	 }
	 Point[] srcTri = new Point[3];
	 srcTri[0] = new Point( 0, 0 );
	 srcTri[1] = new Point( src.cols() - 1, 0 );
	 srcTri[2] = new Point( 0, src.rows() - 1 );
	 Point[] dstTri = new Point[3];
	 dstTri[0] = new Point( 0, src.rows()*0.33 );
	 dstTri[1] = new Point( src.cols()*0.85, src.rows()*0.25 );
	 dstTri[2] = new Point( src.cols()*0.15, src.rows()*0.7 );
	 Mat warpMat = Imgproc.getAffineTransform( new MatOfPoint2f(srcTri), new MatOfPoint2f(dstTri) );
	 Mat warpDst = Mat.zeros( src.rows(), src.cols(), src.type() );
	 Imgproc.warpAffine( src, warpDst, warpMat, warpDst.size() );
	 Point center = new Point(warpDst.cols() / 2, warpDst.rows() / 2);
	 double angle = -50.0;
	 double scale = 0.6;
	 Mat rotMat = Imgproc.getRotationMatrix2D( center, angle, scale );
	 Mat warpRotateDst = new Mat();
	 Imgproc.warpAffine( warpDst, warpRotateDst, rotMat, warpDst.size() );
	 HighGui.imshow( "Source image", src );
	 HighGui.imshow( "Warp", warpDst );
	 HighGui.imshow( "Warp + Rotate", warpRotateDst );
	 HighGui.waitKey(0);
	 System.exit(0);
	 }
	}
public class GeometricTransformsDemo {

	public static void main(String[] args) {
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		 new GeometricTransforms().run(args);
	}

}
