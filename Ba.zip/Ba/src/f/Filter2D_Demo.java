package f;
import org.opencv.core.*;
import org.opencv.core.Point;
import org.opencv.highgui.HighGui;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

class Filter2D_DemoRun {
	 public void run(String[] args) {
	 // Declare variables
	 Mat src, dst = new Mat();
	 Mat kernel = new Mat();
	 Point anchor;
	 double delta;
	 int ddepth;
	 int kernel_size;
	 String window_name = "filter2D Demo";
	 String imageName = ((args.length > 0) ? args[0] : "C:\\cat.jpg");
	 // Load an image
	 src = Imgcodecs.imread(imageName, Imgcodecs.IMREAD_COLOR);

	 // Initialize arguments for the filter
	 anchor = new Point( -1, -1);
	 delta = 0.0;
	 ddepth = -1;
	 // Loop - Will filter the image with different kernel sizes each 0.5 seconds
	 int ind = 0;
	 while( true )
	 {
	 // Update kernel size for a normalized box filter
	 kernel_size = 3 + 2*( ind%5 );
	 Mat ones = Mat.ones( kernel_size, kernel_size, CvType.CV_32F );
	 Core.multiply(ones, new Scalar(1/(double)(kernel_size*kernel_size)), kernel);
	 // Apply filter
	 Imgproc.filter2D(src, dst, ddepth , kernel, anchor, delta, Core.BORDER_DEFAULT );
	 HighGui.imshow( window_name, dst );
	 int c = HighGui.waitKey(500);
	 // Press 'ESC' to exit the program
	 if( c == 27 )
	 { break; }
	 ind++;
	 }
	 System.exit(0);
	 }
	}
public class Filter2D_Demo {

	public static void main(String[] args) {
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		 new Filter2D_DemoRun().run(args);
	}

}
