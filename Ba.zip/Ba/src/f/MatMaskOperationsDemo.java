package f;
import org.opencv.core.*;
import org.opencv.highgui.HighGui;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;
import org.opencv.core.Core.MinMaxLocResult;
import java.util.*;
public class MatMaskOperationsDemo {
	

	 public void run(String[] args) {
		 Mat img = Imgcodecs.imread("image.jpg");
		 Mat grey = new Mat();
		 Imgproc.cvtColor(img, grey, Imgproc.COLOR_BGR2GRAY);
		 Mat sobelx = new Mat();
		 Imgproc.Sobel(grey, sobelx, CvType.CV_32F, 1, 0);
		 MinMaxLocResult res = Core.minMaxLoc(sobelx); // find minimum and maximum intensities
		 Mat draw = new Mat();
		 double maxVal = res.maxVal, minVal = res.minVal;
		 sobelx.convertTo(draw, CvType.CV_8U, 255.0 / (maxVal - minVal), -minVal * 255.0 / (maxVal - minVal));
		 HighGui.namedWindow("image", HighGui.WINDOW_AUTOSIZE);
		 HighGui.imshow("image", draw);
		 HighGui.waitKey();
	 }
	
	
	
	
	public static void main(String[] args) {
		System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
		 new MatMaskOperationsRun().run(args);

	}

}
